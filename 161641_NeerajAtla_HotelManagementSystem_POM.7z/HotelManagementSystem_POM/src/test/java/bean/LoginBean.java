package bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginBean {
	private WebDriver driver;
	@FindBy(tagName="h1")
	private String pageHeading;
	@FindBy(name="userName")
	private WebElement username;
	@FindBy(name="userPwd")
	private WebElement password;
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	private WebElement signBtn;
	public LoginBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this); 

		
	}
	public LoginBean() {
		super();
	}

	public LoginBean(String pageHeading, WebElement username, WebElement password, WebElement signBtn) {
		super();
		this.pageHeading = pageHeading;
		this.username = username;
		this.password = password;
		this.signBtn = signBtn;
	}

	public String getPageHeading() {
		return driver.findElement(By.tagName("h1")).getText();
	}
	public void setPageHeading(String pageHeading) {
		this.pageHeading = pageHeading;
	}
	public String getUsername() {
		return username.getText();
	}
	public void setUsername(String username) {
		this.username.sendKeys(username);
	}
	public String getPassword() {
		return password.getText();
	}
	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	
	public void setSignBtn() {
		this.signBtn.click();
	}
	public void assignValues(String username,String password) {
		setUsername(username);
		setPassword(password);
		
	}

}
